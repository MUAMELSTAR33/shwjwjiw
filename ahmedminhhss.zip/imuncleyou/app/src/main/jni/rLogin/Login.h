#ifndef LOGIN_H
#define LOGIN_H

#include "StrEnc.h"
#include "Includes.h"
#include "Tools.h"
#include "json.hpp"
#include "Log.h"
#include <jni.h>
#include <string>
#include "obfuscate.h"
#include <dirent.h>
#include <sys/stat.h>
#include <vector>
#include <unordered_set>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
using json = nlohmann::ordered_json;
using namespace std;
extern string BypassLink, activity;
extern string cpp1, cpp2, cpp3, cpp4, server1, server2;
extern string name, key_type, logo, telegram, telegram_link2, layoutui, floating_color;
extern string globalstatus, bgmistatus, koreastatus, tiwanstatus, vngstatus, chinastatus, deltaforce;
extern string EXP, real, device;
extern bool xEnv;
static const char* ENCRYPTION_KEY = OBFUSCATE("MTIzNDU2Nzg5MDEyMzQ1Njc4OTAxMjM0NTY3ODkwPYR=");
static const char* SERVER_DOMAIN = OBFUSCATE("arrabxnarouto.site");
static const char* GAMES_LIST = OBFUSCATE("PUBGM,BGMI,PREMIUM,FREE");
static const char* BYPASS_LINK = OBFUSCATE("https://arrabxnarouto.site/bypass/bypass.json");
static const char* ACTIVITY_NAME = OBFUSCATE("pubgm.loader.activity.MainActivity");
static const char* AUTH_TOKEN = OBFUSCATE("Vm8Lk7Uj2JmsjCPKUPjrLkdsbfSDRGdsf");
static const unsigned char UNBREAKABLE_SPKI_PIN[] = {
        0x76, 0x2f, 0x73, 0x2b, 0xc8, 0xa0, 0x0b, 0xbf, 0x9a, 0x83, 0xff, 0xcb,
        0x04, 0x80, 0x23, 0xd0, 0xa0, 0x81, 0xfd, 0xc4, 0xfa, 0xd1, 0xd4, 0x45,
        0x73, 0x80, 0x5d, 0xad, 0x84, 0xa4, 0x0a, 0x33
};
extern "C" jstring AuthCore(JNIEnv *env, jclass, jobject mContext, jstring mUserKey, const char* encKey, const char* domain, const unsigned char* spkiPin, const char* gamesList, const char* bypassLink, const char* activityName, const char* authToken);
int sdasd(JNIEnv *env);
extern "C" JNIEXPORT jstring JNICALL gwieruyrewrt(JNIEnv *env, jclass clazz, jobject mContext, jstring mUserKey) {
return AuthCore(env, clazz, mContext, mUserKey, ENCRYPTION_KEY, SERVER_DOMAIN, UNBREAKABLE_SPKI_PIN, GAMES_LIST, BYPASS_LINK, ACTIVITY_NAME, AUTH_TOKEN);
}
int sdasd(JNIEnv *env) {
    jclass clazz = env->FindClass(OBFUSCATE("pubgm/loader/activity/LoginActivity"));
    if (!clazz) return -1;

    JNINativeMethod methods[] = {
            { (char*)OBFUSCATE("Ahmed"), (char*)OBFUSCATE("(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;"), (void*)gwieruyrewrt }
    };
    return env->RegisterNatives(clazz, methods, 1) < 0 ? -1 : 0;
}
bool signValid = false;
#endif